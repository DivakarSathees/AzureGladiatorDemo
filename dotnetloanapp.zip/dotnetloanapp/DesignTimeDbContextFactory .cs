﻿// using BookStoreDBFirst.Models;
// using Microsoft.EntityFrameworkCore;
// using Microsoft.EntityFrameworkCore.Design;

// public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<LoanApplicationDbContext>
// {
//     public LoanApplicationDbContext CreateDbContext(string[] args)
//     {
//         var optionsBuilder = new DbContextOptionsBuilder<LoanApplicationDbContext>();
//         optionsBuilder.UseSqlServer("ConnectionString");

//         return new LoanApplicationDbContext(optionsBuilder.Options);
//     }
// }
